from django.db import models

# Create your models here.
class cars(models.Model):
    carnm=models.CharField(max_length=100)
    carpr=models.IntegerField(default=0)


