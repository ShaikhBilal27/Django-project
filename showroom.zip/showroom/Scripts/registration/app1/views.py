from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render
from .models import EmpOperations


# Create your views here.
@login_required(login_url='login')



def newemp(request):
    return render(request,"NewEmployee.html")

def HomePage(request):
    return render (request,'home.html')

def SignupPage(request):
    if request.method=='POST':
        uname=request.POST.get('username')
        email=request.POST.get('email')
        pass1=request.POST.get('password1')
        pass2=request.POST.get('password2')

        if pass1!=pass2:
            return HttpResponse("Your password and confrom password are not Same!!")
        else:

            my_user=User.objects.create_user(uname,email,pass1)
            my_user.save()
            return redirect('login')
        



    return render (request,'signup.html')

def LoginPage(request):
    if request.method=='POST':
        username=request.POST.get('username')
        pass1=request.POST.get('pass')
        user=authenticate(request,username=username,password=pass1)
        if user is not None:
            login(request,user)
            return render (request,'NewEmployee.html')
        else:
            return HttpResponse ("Username or Password is incorrect!!!")

    return render (request,'login.html')
    #return render (request, 'login.html')

def LogoutPage(request):
    logout(request)
    return redirect('login')



# def addemp(request):
#     if request.method=="POST":
#         cstid = float(request.POST.get("cstId"))
#         cr = request.POST.get("cars")
#         csnm = request.POST.get("cstNm")
#         crnm = request.POST.get("carNm")
#         ctnm = request.POST.get("ctNm")
#         # call a processing funtion (models)
#         obj=EmpOperations()
#         stat=obj.addnewemployee(cstid, cr, csnm, crnm, ctnm)
#         dic={}
#         dic['cstid']=cstid
#         dic['car']=cr
#         dic['csnm']=csnm
#         dic['crnm']=crnm
#         dic['ctnm']=ctnm
#         dic['status']=stat
#     return render(request,"EmployeeAdded.html",dic)



def addemp(request):
    if request.method == "POST":
        cstid = float(request.POST.get("cstId"))
        cr = request.POST.get("cars")
        csnm = request.POST.get("cstNm")
        crnm = request.POST.get("carNm")
        ctnm = request.POST.get("ctNm")
        Zrice= request.POST.get("price")
        Mobnum= request.POST.get("mobnum")

        try:
            # Call a processing function (models) to add a new employee
            obj = EmpOperations()
            obj.addnewemployee(cstid, cr, csnm, crnm, ctnm,Zrice,Mobnum)
            status = 'success'
        except Exception as e:
            print(e)
            status = 'error'

        # Prepare a context dictionary to pass data to the template
        context = {
            'cstid': cstid,
            'car': cr,
            'csnm': csnm,
            'crnm': crnm,
            'ctnm': ctnm,
            'Zrice': Zrice,
            'Mobnum': Mobnum,
            'status': status,
        }

        return render(request, "EmployeeAdded.html", context)

    return render(request, "EmployeeAdded.html")



def empreport(request):
    obj=EmpOperations()
    data=obj.getreportdata()
    # print(data)
    return render(request,"EmpReport.html",{"list":data})


# def empreport(request):
#     obj = EmpOperations()
#     data = obj.getreportdata()
#     context = {'data': data}
#     return render(request, "EmpReport.html", context)


